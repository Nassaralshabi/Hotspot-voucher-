.class public interface abstract Lc0/i;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(LU1/a;)V
.end method
