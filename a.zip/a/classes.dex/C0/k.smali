.class public final Lc0/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/lifecycle/DefaultLifecycleObserver;


# instance fields
.field public final synthetic p:Landroidx/lifecycle/n;

.field public final synthetic q:Landroidx/emoji2/text/EmojiCompatInitializer;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/EmojiCompatInitializer;Landroidx/lifecycle/n;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc0/k;->q:Landroidx/emoji2/text/EmojiCompatInitializer;

    iput-object p2, p0, Lc0/k;->p:Landroidx/lifecycle/n;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/lifecycle/s;)V
    .locals 3

    iget-object p1, p0, Lc0/k;->q:Landroidx/emoji2/text/EmojiCompatInitializer;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1c

    if-lt p1, v0, :cond_0

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-static {p1}, Lc0/b;->a(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object p1

    goto :goto_0

    :cond_0
    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    :goto_0
    new-instance v0, Lc0/n;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lc0/n;-><init>(I)V

    const-wide/16 v1, 0x1f4

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object p1, p0, Lc0/k;->p:Landroidx/lifecycle/n;

    invoke-virtual {p1, p0}, Landroidx/lifecycle/n;->b(Landroidx/lifecycle/r;)V

    return-void
.end method

.method public final synthetic b(Landroidx/lifecycle/s;)V
    .locals 0

    return-void
.end method

.method public final synthetic c(Landroidx/lifecycle/s;)V
    .locals 0

    return-void
.end method

.method public final synthetic h(Landroidx/lifecycle/s;)V
    .locals 0

    return-void
.end method

.method public final synthetic m(Landroidx/lifecycle/s;)V
    .locals 0

    return-void
.end method

.method public final synthetic s(Landroidx/lifecycle/s;)V
    .locals 0

    return-void
.end method
